# Trabalho 2 PAA
Feito por Gabriel da Silva Souza e José Vitor Santos Alves
# Como rodar
    # Compilar
        make tp2 
    # Rodar .tp2 com entrada.txt
        make run 
    # limpar .o, executaveis, e os txt menos a entrada
        make clean
# Entrada
**1º linha** - Numero de instancias<br>
**2º linha** - numero de Povos = P, distancia que a nave pode andar, peso maximo e numero de caminhos = c<br>
**pº linhas** - povo p, peso e habilidade <br>
**cº linhas**- origem , destino distancia <br>

# Saida
Cada Instancia é salva em diferentes arquivos, com o nome do arquivo indicando qual metodo foi usado, e qual o numero da instancia, dentro do arquivo tem o seguinte formato:<br>
O primeiro valor é a habilidade total, seguido pelo numero do povo visitado, e o numero de habitantes recrutados.
